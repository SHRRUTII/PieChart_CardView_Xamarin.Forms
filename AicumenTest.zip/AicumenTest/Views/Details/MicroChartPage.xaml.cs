﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entry = Microcharts.Entry;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using SkiaSharp;
using Microcharts;
using SkiaSharp.Views.Forms;
using AicumenTest.Models;
using AicumenTest.ViewModels;
using Android.Graphics;
using OxyPlot;
using OxyPlot.Series;
using OxyPlot.Axes;

namespace AicumenTest
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MicroChartPage : ContentPage
    {
        TopCryptoListViewModel vm;
        
        public MicroChartPage()
        {
            vm = new TopCryptoListViewModel();
            InitializeComponent();
            this.BindingContext = vm;
            this.BackgroundColor = Xamarin.Forms.Color.FromHex("#01579B");
     }
       



    }
}