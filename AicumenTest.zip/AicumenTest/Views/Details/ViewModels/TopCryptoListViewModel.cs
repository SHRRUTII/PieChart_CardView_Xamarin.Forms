﻿using AicumenTest.Helper;
using AicumenTest.Models;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Linq;
using Xamarin.Forms;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using System.ComponentModel;
using OxyPlot;
using System.Windows.Input;
using OxyPlot.Series;

namespace AicumenTest.ViewModels
{
    /// <summary>
    /// Top Crypto List ViewModel
    /// </summary>
    public class TopCryptoListViewModel: BaseViewModel,INotifyPropertyChanged
    {
        private PlotModel pieModel { get; set; }

        public PlotModel PieModel
        {
            get
            {
                return pieModel;
            }
            set
            {
                pieModel = value;
            }
        }

       

        public TopCryptoListViewModel()
        {
            if (Application.Current.Properties.ContainsKey("Cryptos"))
            {
                Cryptos = Application.Current.Properties["Cryptos"] as ObservableCollection<Crypto>;
            }

            //Load Top 10 Cryptos 
            LoadTop10Cryptos();
           LoadPieChart();
        }

        public async void LoadPieChart()
        {
            PieModel = null;
            OnPropertyChanged("PieModel");
            var piemodel = new PlotModel { };// { Title = "Kinds of Pet People Own - Independent Survey." };
            var ps = new PieSeries
            {
                StrokeThickness = 0.50,
                AngleSpan = 360,
                StartAngle = 0,
                InsideLabelFormat = "",
                OutsideLabelFormat = "{1}: {0}",
                TickHorizontalLength = 15,
                TickRadialLength = 5,
                TextColor = OxyColor.Parse("#ffffff "),
                TickLabelDistance=4,
                FontSize=8
                
                
         
                
            };

            ps.Slices.Add(new PieSlice("MIOTA",193) { IsExploded = false, Fill = OxyColor.Parse("#FFFFE0") });
            ps.Slices.Add(new PieSlice("ADA",10) { IsExploded = false, Fill = OxyColor.Parse("#C71585") });
            ps.Slices.Add(new PieSlice("USDT",12) { IsExploded = false, Fill = OxyColor.Parse("#800000") });
            ps.Slices.Add(new PieSlice("EOS",45) { IsExploded = false, Fill = OxyColor.Parse("#D2691E") });
            ps.Slices.Add(new PieSlice("XLM",23 ) { IsExploded = false, Fill = OxyColor.Parse("#2F4F4F") });
            ps.Slices.Add(new PieSlice("LTC",24 ) { IsExploded = false, Fill = OxyColor.Parse("#0000FF") });
            ps.Slices.Add(new PieSlice("BTS", 13) { IsExploded = false, Fill = OxyColor.Parse("#008080") });
            ps.Slices.Add(new PieSlice("BCH", 16) { IsExploded = false, Fill = OxyColor.Parse("#808000") });
            ps.Slices.Add(new PieSlice("XRP",17 ) { IsExploded = false, Fill = OxyColor.Parse("#FF4500") });

            ps.Slices.Add(new PieSlice("ETH",7) { IsExploded = false, Fill = OxyColor.Parse("#FFD700") });

            piemodel.Series.Add(ps);
            PieModel = piemodel;

            OnPropertyChanged("PieModel");
        }

        #region INotifyChangedProperties
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
       // Temperory Observable collection used for Sorting purpose
            public ObservableCollection<Crypto> SortingCollection = new ObservableCollection<Crypto>();
        public ObservableCollection<Crypto> saveSortingCollection = new ObservableCollection<Crypto>();

        private ObservableCollection<Crypto> _Cryptos = new ObservableCollection<Crypto>();
        public ObservableCollection<Crypto> Cryptos
        {
            get
            {
                return _Cryptos;
            }
            set
            {
                if (value != null)
                {
                    _Cryptos = value;
                    Notify("Cryptos");
                }
            }
        }

        

        /// <summary>
        /// Load Top 10 Cryptos
        /// </summary>
        public async void LoadTop10Cryptos()
        {
            //Http call for getting Cryptos list from requested web api
            HttpResponseMessage response = await HttpHelper.GetTop10Cryptos("https://api.coinmarketcap.com/v1/ticker/");
            SortingCollection = JsonConvert.DeserializeObject<ObservableCollection<Crypto>>(response.Content.ReadAsStringAsync().Result);

            //Sorting collection based on market_cap_usd property value
            SortingCollection.ToList().Sort((x, y) => x.Market_Cap_USD.CompareTo(y.Market_Cap_USD));
            
            //Clear collection before inserting updated entries
             Cryptos.Clear();

            //Get first 10 items from collection
            foreach (var item in SortingCollection.Skip(0).Take(10))
            {
                item.Price_USD = Convert.ToDecimal(String.Format("{0:0.00}", Convert.ToDecimal(item.Price_USD))).ToString();
                if (item.Percent_change_24h == null)
                {
                    item.Percent_change_24h = "0.00";
                }
                Cryptos.Add(item);
            }

            //Adding upated Top 10 Cryptos into App settings
            Application.Current.Properties["Cryptos"] = Cryptos;
        }


        #endregion INotifyChangedProperties
    }  //}
}
